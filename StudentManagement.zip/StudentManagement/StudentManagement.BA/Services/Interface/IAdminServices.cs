﻿using StudentManagement.DAL.DTO;
using StudentManagement.DAL.Entity;
using System;

namespace StudentManagement.BA.Services.Interface
{
    public interface IAdminServices
    {
        public Task<Admin> AddNewAdmin(Admin admin);
        public Task<Admin> GetAdminDetails(string id);
        public Task<Admin> DeleteAdmin(string id);
        public Task<Admin> UpdateAdmin(Admin admin);
    }
}
