﻿using StudentManagement.DAL.DTO;
using StudentManagement.DAL.Entity;
using System;

namespace StudentManagement.BA.Services.Interface
{
    public interface IUserServices
    {
        public Task<User> AddNewUser(User user);
        public Task<User> GetUserDetail(string id);
        public Task<User> DeleteUser(string id);
        public Task<User> UpdateUser(User user);
    }
}
