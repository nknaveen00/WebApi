﻿using StudentManagement.BA.Services.Interface;
using StudentManagement.DAL.DTO;
using StudentManagement.DAL.Entity;
using StudentManagement.DAL.Repository.Interface;
using System;

namespace StudentManagement.BA.Services
{
    public class AdminServices : IAdminServices
    {
        private readonly IAdminRepository adminRepository;

        public AdminServices(IAdminRepository adminRepository)
        {
            this.adminRepository = adminRepository;
        }

        public async Task<Admin> AddNewAdmin(Admin admin)
        {
            return  await adminRepository.AddNewAdmin(admin);
        }

        public async Task<Admin> DeleteAdmin(string id)
        {
            return await adminRepository.DeleteAdmin(id);
        }

        public async Task<Admin> GetAdminDetails(string id)
        {
            return await adminRepository.GetAdminDetail(id);
        }

        public async Task<Admin> UpdateAdmin(Admin admin)
        {
            return await adminRepository.UpdateAdmin(admin);
        }
    }
}
