﻿using StudentManagement.BA.Services.Interface;
using StudentManagement.DAL.DTO;
using StudentManagement.DAL.Entity;
using StudentManagement.DAL.Repository.Interface;
using System;

namespace StudentManagement.BA.Services
{
    public class UserServices : IUserServices
    {
        private readonly IUserRepository userRepository;

        public UserServices(IUserRepository userRepository)
        {
            this.userRepository = userRepository;
        }

        public async Task<User> AddNewUser(User user)
        {
            return await userRepository.AddNewUser(user);
        }

        public async Task<User> DeleteUser(string id)
        {
            return await userRepository.DeleteUser(id);  
        }

        public async Task<User> GetUserDetail(string id)
        {
            return await userRepository.GetUserDetail(id);
        }

        public async Task<User> UpdateUser(User user)
        {
            return await userRepository.UpdateUser(user);
        }
    }
}
