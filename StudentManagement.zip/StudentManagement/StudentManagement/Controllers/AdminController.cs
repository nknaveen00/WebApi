﻿using Microsoft.AspNetCore.Mvc;
using StudentManagement.BA.Services.Interface;
using StudentManagement.DAL.DTO;
using StudentManagement.DAL.Entity;

namespace StudentManagement.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AdminController : Controller
    {
        private readonly IAdminServices adminServices;

        public AdminController(IAdminServices adminServices)
        {
            this.adminServices = adminServices;
        }

        [HttpGet]
        public async Task<ActionResult<Admin>> GetAdminDetail(string id)
        {
            var response = await adminServices.GetAdminDetails(id);
            if(response == null)
                return NotFound();

            return Ok(response);
        }


        [HttpPost]
        public async Task<ActionResult<Admin>> AddNewAdmin(Admin admin)
        {
            var response = await adminServices.AddNewAdmin(admin);
            if (response == null)
                return NotFound();
            return Ok(response);
        }

        [HttpDelete]
        public async Task<ActionResult<Admin>> DeleteAdmin(string id)
        {
            var response = await adminServices.DeleteAdmin(id);
            if (response == null)
                return NotFound();
            return Ok(response);
        }

        [HttpPut]
        public async Task<ActionResult<Admin>> UpdateAdmin(Admin admin)
        {
            var response = await adminServices.UpdateAdmin(admin);
            if (response == null)
                return NotFound();
            return Ok(response);
        }
    }
}
