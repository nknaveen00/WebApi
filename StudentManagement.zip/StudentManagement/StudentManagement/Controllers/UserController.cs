﻿using Microsoft.AspNetCore.Mvc;
using StudentManagement.BA.Services.Interface;
using StudentManagement.DAL.DTO;
using StudentManagement.DAL.Entity;

namespace StudentManagement.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : Controller
    {
        private readonly IUserServices userServices;

        public UserController(IUserServices userServices)
        {
            this.userServices = userServices;
        }

        [HttpGet]
        public async Task<ActionResult<User>> GetUserDetail(string id)
        {
            var response = await userServices.GetUserDetail(id);

            if (response == null)
                return NotFound();

            return Ok(response);
        }

        [HttpPost]
        public async Task<ActionResult<User>> AddNewUser(User user)
        {
            var response = await userServices.AddNewUser(user);
            if (response == null)
                return NotFound();
            return Ok(response);
        }

        [HttpDelete]
        public async Task<ActionResult<User>> DeleteUser(string id)
        {
           var response = await userServices.DeleteUser(id);
            if (response == null)
                return NotFound();
            return Ok();
        }

        [HttpPut]
        public async Task<ActionResult<User>> UpdateUser(User user)
        {
            var response = await userServices.UpdateUser(user);
            if (response == null)
                return NotFound();
            return Ok();
        }

    }
}
