﻿using System;

namespace StudentManagement.DAL.DTO
{
    public class UpdateAdminUser
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
