﻿using System;

namespace StudentManagement.DAL.DTO
{
    public class GetAdminUserLog
    {
        public String UserId { get; set; }
        public string Password { get; set; }
    }
}
