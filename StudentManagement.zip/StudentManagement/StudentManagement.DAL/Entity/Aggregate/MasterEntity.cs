﻿using System;

namespace StudentManagement.DAL.Entity.Aggregate
{
    public class MasterEntity
    {
        public Guid Id { get; set; }
    }
}
