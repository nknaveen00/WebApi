﻿using StudentManagement.DAL.Entity.Aggregate;
using System;

namespace StudentManagement.DAL.Entity
{
    public class Admin : MasterEntity
    {
        public String UserId { get; set; }
        public String FirstName { get; set; }
        public String LastName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
