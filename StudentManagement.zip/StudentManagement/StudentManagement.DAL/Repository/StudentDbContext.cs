﻿using Microsoft.EntityFrameworkCore;
using StudentManagement.DAL.Entity;
using System;

namespace StudentManagement.DAL.Repository
{
    public class StudentDbContext : DbContext
    {
        public StudentDbContext(DbContextOptions<StudentDbContext> options) : base(options)
        {

        }

        public DbSet<Admin> Admin { get; set; }
        public DbSet<User> Users { get; set; }
    }
}
