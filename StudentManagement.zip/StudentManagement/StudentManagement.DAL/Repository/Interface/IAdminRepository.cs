﻿using StudentManagement.DAL.DTO;
using StudentManagement.DAL.Entity;
using System;

namespace StudentManagement.DAL.Repository.Interface
{
    public interface IAdminRepository
    {
        public Task<Admin> AddNewAdmin(Admin admin);
        public Task<Admin> GetAdminDetail(string id);
        public Task<Admin> DeleteAdmin(string id);
        public Task<Admin> UpdateAdmin(Admin admin);
    }
}
