﻿using StudentManagement.DAL.DTO;
using StudentManagement.DAL.Entity;
using System;

namespace StudentManagement.DAL.Repository.Interface
{
    public interface IUserRepository
    {
        public Task<User> AddNewUser(User user);
        public Task<User> GetUserDetail(string id);
        public Task<User> DeleteUser(string id);
        public Task<User> UpdateUser(User user);
    }
}
