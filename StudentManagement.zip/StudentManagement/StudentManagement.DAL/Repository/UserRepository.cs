﻿using StudentManagement.DAL.DTO;
using StudentManagement.DAL.Entity;
using StudentManagement.DAL.Repository.Interface;
using System;

namespace StudentManagement.DAL.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly StudentDbContext studentDb;

        public UserRepository(StudentDbContext studentDb)
        {
            this.studentDb = studentDb;
        }

        public async Task<User> AddNewUser(User user)
        {
            await studentDb.Users.AddAsync(user);
            studentDb.SaveChanges();
            return studentDb.Users.FirstOrDefault(x => x.UserId == user.UserId);
        }

        public async Task<User> DeleteUser(string id)
        {
            var data = studentDb.Users.FirstOrDefault(x => x.UserId == id);
            studentDb.Users.Remove(data);
            await studentDb.SaveChangesAsync();
            return data;
        }

        public async Task<User> GetUserDetail(string id)
        {
            return studentDb.Users.FirstOrDefault(x => x.UserId == id);
        }

        public async Task<User> UpdateUser(User user)
        {
            var data=studentDb.Users.FirstOrDefault(x => x.UserId == user.UserId);
            studentDb.Users.Remove(data);
            await studentDb.Users.AddAsync(user);
            await studentDb.SaveChangesAsync();
            return studentDb.Users.FirstOrDefault(x => x.UserId == user.UserId);
        }
    }
}
