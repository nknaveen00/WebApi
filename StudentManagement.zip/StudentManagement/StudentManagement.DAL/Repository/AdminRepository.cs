﻿using AutoMapper;
using StudentManagement.DAL.DTO;
using StudentManagement.DAL.Entity;
using StudentManagement.DAL.Repository.Interface;
using System;

namespace StudentManagement.DAL.Repository
{
    public class AdminRepository : IAdminRepository
    {
        private readonly StudentDbContext studentDb;

        public AdminRepository(StudentDbContext studentDb)
        {
            this.studentDb = studentDb;
        }

        public async Task<Admin> AddNewAdmin(Admin admin)
        {
            await studentDb.Admin.AddAsync(admin);
            await studentDb.SaveChangesAsync();
            return studentDb.Admin.FirstOrDefault(x => x.UserId == admin.UserId);
        }

        public async Task<Admin> DeleteAdmin(string id)
        {
            var data =  studentDb.Admin.FirstOrDefault(x => x.UserId == id);
            studentDb.Admin.Remove(data);
            await studentDb.SaveChangesAsync();
            return studentDb.Admin.FirstOrDefault(x => x.UserId == id);
        }

        public async Task<Admin> GetAdminDetail(string id)
        {
            return studentDb.Admin.FirstOrDefault(x => x.UserId == id);
        }

        public async Task<Admin> UpdateAdmin(Admin admin)
        {
            var data=studentDb.Admin.FirstOrDefault(x=>x.UserId==admin.UserId);
            studentDb.Remove(data);
            await studentDb.Admin.AddAsync(admin);
            await studentDb.SaveChangesAsync();
            return studentDb.Admin.FirstOrDefault(x => x.UserId == admin.UserId);
        }
    }
}
